# Ce fichier contiendra toutes les fonctions pour communiquer avec la base de donnée
import sqlite3
import datetime

con = sqlite3.connect("E:\Documents\Véronica\Veronica\Database\Veronica.db")

def UserExist(id:int)->bool:
    cur = con.cursor()
    Recup = 'SELECT COUNT(*) FROM user WHERE ID_Discord={}'.format(id)
    cur.execute(Recup)
    Verif = cur.fetchone()[0]
    if not Verif:
        return False
    return True
def getUserMoney(id:int)->int:
    """Retourne la quantité d'argent de l'utilisateur"""
    if UserExist(id):
        cur = con.cursor()
        cur.execute("SELECT money FROM user WHERE id_discord={}".format(id))
        result=cur.fetchone()[0]
        return result
def getUserLvl(id:int)->int:
    """Sélectionne le niveau du joueur. Je récupère la liste des niveaux dont l'xp requis est en dessous de ce qu'il a, et le dernier de la liste défini son niveau"""
    if UserExist(id):
        cur = con.cursor()
        cur.execute("SELECT Level FROM user WHERE id_discord={}".format(id))
        result=cur.fetchall()
        return result[-1][0]
def getRequireXPLvl(lvl:int)->int:
    cur = con.cursor()
    cur.execute("SELECT Xp_requise FROM Levels WHERE Niveau={}".format(lvl))
    result=cur.fetchall()
    return result[0][0]
def getUserXPPourcentage(id)->int:
    """Donne l'avancement du niveau de l'utilisateur à propos de son xp, sous forme de pourcentage"""
    if UserExist(id):
        curXP=getUserXP(id)
        return (curXP / getRequireXPLvl(getUserLvl(id)+1))*100
def getUserXP(id)->int:
    if UserExist(id):
        cur = con.cursor()
        cur.execute("SELECT xp FROM user WHERE id_discord = {}".format(id))
        curXP=cur.fetchall()
        return curXP[0][0]
def setUserXp(id,amont:int=None,x:int=0):
    """Définie l'xp de l'utilisateur. Amont correspond à l'xp à définir, par défaut à None. x correspond à de l'xp à additionner"""
    if UserExist(id):
        if amont==None:
            amont=getUserXP(id)
        cur = con.cursor()
        cur.execute("UPDATE user SET xp = {} WHERE id_discord={}".format(amont+x,id))
        con.commit()
        return getUserXP(id)
    

def createUser(id:int)->int:
    """Créer le profile d'un utilisateur"""
    if not UserExist(id):
        cur = con.cursor()
        today = datetime.datetime.now()
        insertdata = """INSERT INTO user VALUES (?,0,NULL,?,10,0);"""
        cur.execute(insertdata,(id,today))
        con.commit()
def setUserMoney(id,amont:int=None,x:int=0)->int:
    """Définie l'argent de l'utilisateur. Amont correspond à l'argent à définir, par défaut à None. x correspond à de l'argent à additionner"""
    if UserExist(id):
        if amont==None:
            amont = getUserMoney(id)
        cur = con.cursor()
        cur.execute("UPDATE user SET money = {} WHERE id_discord={}".format(amont+x,id))
        con.commit()
    return getUserMoney(id)
def dailyMoney(id)->int:
    if UserExist(id):
        today = datetime.datetime.now()
        if DailyCooldownNone(id) or DayBetween(today,getDailyCooldown(id)) >= 1:
            cur = con.cursor()
            today=today.strftime("%y-%m-%d %H:%M:%S")
            cur.execute("UPDATE user SET daily_cooldown='{}' WHERE id_discord={};".format(today,id))
            con.commit()
            setUserMoney(id,None,150)
    return getUserMoney(id)

def DailyCooldownNone(id)->bool:
    if UserExist(id):
        cur = con.cursor()
        cur.execute("SELECT daily_cooldown FROM user WHERE id_discord={}".format(id))
        temp=cur.fetchall()[0][0]
        if temp==None:
            return True
        else:
            return False
    else:
        return False
def getDailyCooldown(id)->datetime:
    cur = con.cursor()
    cur.execute("SELECT daily_cooldown FROM user WHERE id_discord={}".format(id))
    temp=cur.fetchall()[0][0]
    temp=datetime.datetime.strptime(temp,"%y-%m-%d %H:%M:%S")
    return temp
def DayBetween(time1,time2):
    temp=time1-time2
    return temp.days

createUser(323147727779397632)
print(getUserMoney(323147727779397632))
print(getUserLvl(323147727779397632))
print(setUserMoney(323147727779397632,1000))
print(setUserMoney(323147727779397632,None,10))
print(dailyMoney(323147727779397632))
print("Xp requis pour lvl up : {}".format(getRequireXPLvl(getUserLvl(323147727779397632)+1)))
print(getUserXPPourcentage(323147727779397632))
print(setUserXp(323147727779397632,50))